# Chat UI

A Pen created on CodePen.io. Original URL: [https://codepen.io/shivapandey/pen/dWdRYM](https://codepen.io/shivapandey/pen/dWdRYM).

This is a HTML, CSS, JS chatbox design. 